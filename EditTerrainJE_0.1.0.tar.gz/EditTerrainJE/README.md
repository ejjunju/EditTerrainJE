# EditTerrainJE
Interactively edit terrain. Perform cuts and fills in terrain using lines with start and end elevations
